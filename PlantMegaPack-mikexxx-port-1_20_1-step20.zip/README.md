# PlantMegaPack mikexxx port (Forge 1.20.1)
Upload this folder (or the zip) to a GitHub repo -> Actions tab -> "build-jar" -> download the jar artifact.
Honeycomb on a plant = waxed (stops growing). Axe removes wax. Bone meal = +1 growth stage.

Added in this revision:
- Planters (59), flower pots (32), wall brackets (26 incl. 1.7.10 stone/gem ones), bamboo poles (9), bamboo walls (9),
  fruitwood bark, potting table (opens a 3x3 crafting grid).
- 241 crafting recipes converted from the 1.12.2 version (+ item tags food_vegetable/fruit/berry/nut/rice/bread/mushroom).
- Latin names for all species/cultivar plants (shown as grey italic tooltip).

Not ported: world generation, advancements, trellis / trellis tower (no assets in the 1.12.2 jar), curled brackets, cactus spike items.

Rev 3:
- Removed duplicate plants (same texture, different name): kept the specific 1.7.10 cultivar names, kept 1.12.2 colours only where 1.7.10 has none.
  Flowers are sorted by plant, then rainbow order (dark red -> red -> coral -> orange -> yellow -> green -> cyan -> blue -> royal -> purple -> magenta -> pink -> white).
- Tall plants are separate blocks: 1.12.2 3-segment plants = Bottom / Middle / Top blocks, 2-block plants = Bottom / Top blocks,
  1.7.10 plants with 6/8/10 stage textures = one block per stage (Stage 1..n). Plants with 2-5 stages still grow with bone meal.
- Epiphytes (18) are wall-mounted blocks that attach to the side of logs/blocks.

Rev 4:
- Medium / large plants are ONE block + ONE item again. 1.7.10 'DOUBLE' plants (taken from the jar's plant table): 2 single-block stages, then
  bottom/top pairs from stage 3 on (growing via bone meal / random ticks, the top is placed when it reaches a 2-block stage). 1.12.2 large plants
  (3 segments, 2 wide) and 2-segment plants use the jar's own models. Honeycomb waxes all segments, axe removes the wax.
- Stage-split entries removed: every single-block growth plant is one inventory item.
- Berry bushes: right-click when fully grown -> berries drop, the bush goes back to an earlier stage.
- Flowers tab: rainbow-order colour flowers first, then flowers with colour families kept together in rainbow order.
- All mod tabs are chained so they sit next to each other.

Rev 5:
- Medium plants (Burning Bush, Cinnamon Fern, Dwarf Pine, Japanese Pieris, Prairie Junegrass, Sheep Laurel, Slender Firethorn, Woolly Bush,
  Yellow Jasmine) are now the real 2-tall/2-wide 1.12.2 plants (one block, bottom/top).
- Tillandsia Ionantha is its own epiphyte again (separate from Sky Plant).
- Creative tabs follow the original mods: Flowers, Overworld Plants, Crops, Aquatic Plants, Trees, Food, Crafting. Their registry names start with
  0_..6_ and are chained, so they stay together and in this order.
- Colour families are sorted by number of colours (most first, rainbow order inside), the rest follows.
- Ground covers and floating plants (water lilies etc.) are flat on the ground/water with random rotation instead of crosses.
- Hanging plants are whole pieces now (1.12.2 ones use top+bottom textures, 1.7.10 ones their complete single-block texture).

## 1.3.0 changes
- Single mod again: your original source + fixes merged in (no pre-compiled `base/`, no extension mod). Build output is ONE jar.
- Hanging plants: new `HangingPlantBlock` (2 blocks; 1.12.2 vines and sweet peas 3 blocks). Attach to ceilings, leaves, chains (vanilla + modded), wall brackets, hooks.
- Water plants: new `WaterPlantBlock`
  - aquatic crops (rice, wild rice, centella, laksa leaf, watercress, water spinach): only in 1-block-deep water on soil
  - lotus / wasabi / taro: in 1-deep water OR on soil/mud next to water OR on mud
  - immersed plants: bottom block in 1-deep water, upper 1-2 blocks above the surface (grow after the last stage)
  - all grow (random tick + bone meal), honeycomb waxes, axe removes wax
- Tall crops (brussels sprout, burdock, cassava, land cress, orache, skirret, corn): stage -> frame mapping fixed.
- Creative tab "PMP: All Plants (colour filter)" + `config/pmp_mikexxx/plant_colors.json`.
- Duplicate Tillandsia ionantha removed (kept "Sky Plant").
- German translation completed (de_de.json): every key translated, swapped cultivar names fixed, "(Stufe n)" suffixes removed.

## 1.4.0 changes
- Leaves: all 55 leaf blocks are tinted again. The leaf textures are grey on purpose; the original mod tints every tree with a FIXED colour
  (not the biome colour). Those colours were read from the original 1.12.2 jar (`DefTree`) and are applied to the block and the item
  (`ClientColors`). Leaf item names use the same colour.
- Water crops (Wasabi, Watercress, Water Spinach, Wild Rice, Asian Rice, Centella, Laksa Leaf, Sacred Lotus, Taro) are real two-block plants with
  5 growth stages: lower block in the water (even 1.7.10 texture 0/2/4/6/8), upper block above the water (odd texture 1/3/5/7/9). Both blocks
  change with every stage. Placing needs free space above; breaking either half drops the plant once. Bone meal / random ticks / honeycomb work on both halves.
- Colour tab: Cephalanthera rubra -> purple, Pachystachys lutea -> yellow, Mertensia ciliata -> purple, Liatris punctata -> purple,
  Dodecatheon meadia -> pink, Cordyline fruticosa -> red, Porcelain Berry -> purple, Kiwi -> yellow, and 23 green hanging plants (bamboos, foliage,
  philodendrons, ivies, creepers, ...) -> green.
- Config `config/pmp_mikexxx/plant_colors.json`: every line is now `"id   # Name (Latin)"` (only the id before the `#` counts). When the mod ships new
  defaults (`_version`), the old file is kept as `plant_colors.old-vN.json` and a new one is written.
- Vines: the 9 `vine_*` plants + 13 wisteria vines are real vines (`PmpVineBlock`, vanilla vine behaviour: cling to blocks, spread, climbable,
  tapered end texture at the bottom). The 9 sweet peas + 9 other `climbing_*` plants (grape, kiwi, hop, ...) are wall-climbing plants
  (`ClimbingPlantBlock`): attach to the side of a block, climbable, 4 growth stages, grow upwards when fully grown (max 6 blocks), honeycomb/axe.

## 1.5.0 changes (ported from the real 1.6.4 mod, PlantMegaPack 2.20)
- New plants: the spooky row (Bat Orchid, Burnt Rose, Devils Claw, Octopus Stinkhorn, Porcupine Tomato, Claw Shrub, Thorn Bush, White Baneberry, 3-block Dead Tree),
  Trained Cedar, Crown Imperial, Sun Bromeliad, Erechtites hieracifolia. Checked against the port by id, name, latin name and texture first - the cylinder/globe/pyramid
  cedars, prickly lettuce, golden spined cactus (= Golden Cereus) and the dandelion sizes (= growth stages) were already in the port.
- Spooky effects (`effect` field in pmp_entries.json): "thorns" (Devils Claw, Porcupine Tomato, Claw Shrub, Thorn Bush) slows and hurts like a sweet berry bush,
  "poison" (White Baneberry, Octopus Stinkhorn) gives short poison. The assignment is a guess from the plant names, change it in pmp_entries.json.
- Classic ferns (2.20 art, 6 small + 3 tall): the grey `...C` textures of the old mod are a second layer tinted with the biome grass colour (`biome: true`, tintindex 0;
  inventory icon uses layer1 tint). Tall classic ferns: top block is biome tinted.
- Dwarf berry bushes replace the "1.7.10" berry row: `berrybush_dwarf_*`, named "Dwarf <Berry> Bush". Beauty/Black(Bramble)/Blue/Orange/Straw use the 2.20 textures
  (bare bush -> berries), elder/goose/huckle/snow keep their 1.7.10 art because 2.20 has no texture for them. Dwarf bushes drop 1-2 berries (mostly 1), big bushes 1-3.
  The real "<Berry> Bush" row (8 stages) is untouched.
- Dwarf Palmetto: new `PalmettoBlock`, a single double-sided plane (the original FLAT render type) that turns to face the player when placed (8 angles, `rot` property).
- Colour tab: Hanging Lavender -> purple, Brittlebush (both) -> yellow, new dark/spooky plants -> other. `ColorConfig.CONFIG_VERSION` is 3, so existing
  config/pmp_mikexxx/plant_colors.json files are regenerated (old one is kept as backup).

## 1.6.0 changes
- Berry bushes: normal bushes (1.7.10 / 1.12.2 art, 8 stages) are the only "<Berry> Bush" row; their inventory icon is the late (berry) stage like the 1.12.2 item model.
  Dwarf bushes are now ONLY the five real 1.6.4 / 2.20 ones (Beauty, Blue, Bramble, Orange, Straw), 2 stages (bare -> berries).
  Removed the four fake dwarf bushes (Elder, Gooseberry, Huckleberry, Snowberry) that used the big 1.7.10 art.
- Crops: item icons now show the grown plant (last growth stage; the more filled half for 2-block crops) instead of the empty seedling.
- Water crops (rice, wild rice, centella, laksa leaf, watercress, water spinach, lotus, wasabi, taro): first growth stage is now a small seedling in the lower block
  (upper block empty); full stalk + leaves only from stage 2 on.
- Taro Root: `item_food_taro_root` + `root_taro` merged into ONE item (`item_food_taro_root`): right-click a block = plant taro, right-click air = eat. `crop_taro` (the plant) stays.
- Trained Cedar stays a single block (in 1.6.4 only Cylinder and Pyramid cedar are double blocks).
- Colour config version 4 (old plant_colors.json is backed up and regenerated, removed bushes dropped).

## 1.7.0 (work in steps)
### Step 1 - duplicates merged, seeds and roots plant their crops
- Same name + identical texture = one item: Quinoa Seeds, Rice (seed + food), Prickly Pear Fruit, Quinoa Cereal, Water Chestnut (root + food), Seaweed Wrap.
  References in recipes / tags were redirected to the kept item.
- Every seed, root and stem now plants its crop (`plant` field in pmp_entries.json): right-click a block = plant, right-click air = eat (if it is food).
  Water chestnut plants the floating water chestnut (`PmpFloatingSeedItem`: right-click water).
- Not merged although they look alike (different art or different name): Sacred Lotus Root, Wasabi Stem, the veget_* / item_food_* vegetable pairs, Healing/Health Salve, the wrap and fruit drink pairs.

### Step 2 - dwarf bushes complete, plants tab order
- New dwarf bushes Elder (yellow), Gooseberry (pale green), Huckleberry (dark blue-violet), Snowberry (white): the 2.20 bush texture with the berry pixels recoloured
  (same 2-stage bare -> berries logic as the other dwarf bushes, same harvest items). Now 9 big + 9 dwarf bushes.
- Overworld plants tab: berry row (normal) first, the dwarf row directly below it, the Angel's Trumpets moved down behind them.

### Step 3 - ferns and the dead tree (no 3-block plants below 1.12.2)
- Removed my wrong "Classic" ferns (single + the three 3-block tall ones). There is only ONE variety of each fern now.
- The 6 ferns that had grey tint overlays in 1.6.4 (Hay Scented, Maidenhair Spleenwort, Ostrich, Scaly Tree, Sword, Woodsia) are biome tinted: every stage texture
  (incl. the bottom/top halves of the 2-block stages) has a grey `*_biome` twin that is tinted with the biome grass colour (block + inventory item).
  Scaly Tree Fern keeps its 5 growth stages: 1 block -> 2 blocks, never 3.
- Dead Tree (2.20) is now 2 stages: young tree (1 block, texture A) -> grown tree (bottom B + top T = 2 blocks). The only 3-block plants left are the 1.12.2 `large_*` ones.

### Step 4 - colour tab
- Config file renamed: `config/pmp_mikexxx_colortab.json` (was `config/pmp_mikexxx/plant_colors.json`; the built-in defaults are `pmp_mikexxx_colortab.json` in the jar). Config version 5:
  an older colour-tab file is backed up as `pmp_mikexxx_colortab.old-vN.json` and regenerated. The old `plant_colors.json` is simply no longer used.
- Every colour group is sorted by shade from the plant textures (pink: bubblegum -> lighter -> more orange pinks; same hue-walk for red, orange, yellow, green, blue, cyan, purple, burgundy;
  whites by brightness). The "all" filter shows the groups one after another in that order.

## 1.7.1 (merge of the safe port and the step-4 port)
- Base: step-4 port (dwarf bushes Elder/Gooseberry/Huckleberry/Snowberry recoloured, seeds/roots plant their crops, duplicates merged, colour tab). Nothing from the safe port was dropped except the merged duplicates.
- Ferns: Hay Scented, Maidenhair Spleenwort, Ostrich, Scaly Tree, Sword and Woodsia are the plain 1.7.10 ferns with their growth stages again (no biome tint, no grey twin textures).
  Ostrich / Scaly Tree / Sword: 2 single-block stages, then 2-block stages.
- Dead Tree: pure 2-block plant (bottom + top), 1.6.4 art; the young one-block stage is gone.
- Re-added: Orange Angel's Trumpet (1.12.2 `large_angtr_ora`; the 1.12.2 lang file defines `large_angtr_red` twice, so the orange name was lost) and Spearleaf Stonecrop (1.12.2 `forec_stosp`).
- Grey (`*C`) 2.20 textures are NOT used for anything now.

## 1.8.0 (work in steps, built on 1.7.1)
### Step 1 - crops
- Crop-tab item icons: every double-block crop shows its UPPER, fully grown block (water crops `_9`, tall crops the `_t` / top texture).
- Crop blocks no longer drop themselves. A crop gives back its seed/root when young (1), and when fully grown seeds (1-2) + produce (1-3).
  If seed and produce are the same item (rice, wild rice, lentils, peanuts, soybeans, taro, lotus, wasabi) you get one evened-out amount (2-4).
  Centella, Laksa Leaf, Watercress and Water Spinach have no seed: they give their leaves, and those leaves (Spinach for Water Spinach) plant the crop again.
- Planting soil: wild plants only stand on soil (dirt tag: dirt, grass, podzol, coarse dirt, mycelium, rooted dirt, moss, mud) or sand. Crops (crop tab, quinoa) stand on
  farmland and the dirt tag, never on stone. Underwater plants (corals, seaweed ...) and water crops keep their own rules. Planters/pots still work.
### Step 2 - leaves, fruiting vines, seeds
- Leaves (`PmpLeavesBlock`): the DEFAULT state is persistent, so leaves placed by hand, from the creative inventory, harvested with shears and placed again, or by WorldEdit/commands
  never decay. Leaves created by a grown tree (sapling, bone meal, `TreeGen`) are NOT persistent: without a log within 6 blocks they decay like in vanilla.
  The fruit tree logs (`log_frtwd`, `logst_frtwd`) are now in `minecraft:logs`, so they hold leaves.
- Leaf drops: shears / silk touch give the leaf. Otherwise a decaying or broken leaf drops the tree's sapling (5 %, fortune improves it) and, for the 29 trees that have a fruit or nut, sometimes that fruit/nut.
- Fruiting vines: Kiwifruit, Common Grape Vine, Golden Hop, Hyacinth Bean and Porcelain Berry give Kiwi / Purple Grapes / Hops / Hyacinth Beans / Porcelain Berries on right-click once a block is fully grown
  (1-2 items, the block goes back to stage 1 and ripens again; honeycomb still waxes).
- Seeds: the planting fix is the farmland rule from step 1 (before, nothing could be planted on farmland). Every seed / root / stem item already planted its crop.
