package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Very small generic tree builder: straight trunk + round or conical crown. */
public final class TreeGen {
    private TreeGen() {}

    private static boolean free(BlockState s) {
        return s.isAir() || s.canBeReplaced() || s.is(BlockTags.LEAVES);
    }

    public static boolean grow(ServerLevel lv, BlockPos pos, Block log, Block leaf, boolean conifer, int baseH, RandomSource r) {
        int h = baseH + r.nextInt(3);
        for (int y = 1; y <= h + 1; y++) if (!free(lv.getBlockState(pos.above(y)))) return false;
        BlockState logS = log.defaultBlockState();
        BlockState leafS = leaf.defaultBlockState();
        // naturally grown leaves are NOT persistent: they decay when no log is near (distance is corrected by a scheduled tick)
        if (leafS.hasProperty(LeavesBlock.PERSISTENT)) leafS = leafS.setValue(LeavesBlock.PERSISTENT, false);
        if (leafS.hasProperty(LeavesBlock.DISTANCE)) leafS = leafS.setValue(LeavesBlock.DISTANCE, 6);
        for (int y = 0; y < h; y++) lv.setBlock(pos.above(y), logS, 3);
        if (conifer) {
            for (int y = h; y >= 2; y--) {
                int rad = Math.min(3, (h - y + 1) / 2);
                put(lv, pos.above(y), rad, leafS, r, rad > 1);
            }
            lv.setBlock(pos.above(h), leafS, 3);
            lv.setBlock(pos.above(h + 1), leafS, 3);
            lv.scheduleTick(pos.above(h), leafS.getBlock(), 1);
            lv.scheduleTick(pos.above(h + 1), leafS.getBlock(), 1);
        } else {
            for (int y = h - 3; y <= h + 1; y++) {
                int rad = y >= h ? 1 : 2;
                put(lv, pos.above(y), rad, leafS, r, rad == 2);
            }
        }
        return true;
    }

    private static void put(ServerLevel lv, BlockPos c, int rad, BlockState leafS, RandomSource r, boolean trimCorners) {
        for (int dx = -rad; dx <= rad; dx++)
            for (int dz = -rad; dz <= rad; dz++) {
                if (trimCorners && Math.abs(dx) == rad && Math.abs(dz) == rad && r.nextBoolean()) continue;
                BlockPos p = c.offset(dx, 0, dz);
                BlockState cur = lv.getBlockState(p);
                if (cur.isAir() || cur.canBeReplaced() || cur.is(BlockTags.LEAVES)) {
                    lv.setBlock(p, leafS, 3);
                    lv.scheduleTick(p, leafS.getBlock(), 1);
                }
            }
    }
}
