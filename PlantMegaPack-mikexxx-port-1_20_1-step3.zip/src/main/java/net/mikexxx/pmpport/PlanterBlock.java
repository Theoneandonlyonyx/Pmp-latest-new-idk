package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

/** Planter that visually connects to neighbouring planters (models are chosen by the 4 booleans). */
public class PlanterBlock extends Block {
    public static final BooleanProperty NORTH = BlockStateProperties.NORTH;
    public static final BooleanProperty EAST = BlockStateProperties.EAST;
    public static final BooleanProperty SOUTH = BlockStateProperties.SOUTH;
    public static final BooleanProperty WEST = BlockStateProperties.WEST;

    public PlanterBlock(Properties p) {
        super(p);
        registerDefaultState(stateDefinition.any().setValue(NORTH, false).setValue(EAST, false).setValue(SOUTH, false).setValue(WEST, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(NORTH, EAST, SOUTH, WEST);
    }

    private static BooleanProperty prop(Direction d) {
        return switch (d) {
            case NORTH -> NORTH;
            case EAST -> EAST;
            case SOUTH -> SOUTH;
            default -> WEST;
        };
    }

    private static boolean connects(BlockState other) {
        return other.getBlock() instanceof PlanterBlock;
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext c) {
        BlockGetter l = c.getLevel();
        BlockPos pos = c.getClickedPos();
        BlockState s = defaultBlockState();
        for (Direction d : Direction.Plane.HORIZONTAL) s = s.setValue(prop(d), connects(l.getBlockState(pos.relative(d))));
        return s;
    }

    @Override
    public BlockState updateShape(BlockState s, Direction d, BlockState n, LevelAccessor l, BlockPos p, BlockPos np) {
        if (d.getAxis().isHorizontal()) return s.setValue(prop(d), connects(n));
        return s;
    }
}
