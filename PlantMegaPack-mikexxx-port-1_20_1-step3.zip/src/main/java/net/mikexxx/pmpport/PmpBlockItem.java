package net.mikexxx.pmpport;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

import javax.annotation.Nullable;
import java.util.List;

public class PmpBlockItem extends BlockItem {
    final int color;
    final String latin;
    final int stages;

    public PmpBlockItem(Block b, Properties p, int color, String latin, int stages) {
        super(b, p);
        this.color = color;
        this.latin = latin;
        this.stages = stages;
    }

    @Override
    public Component getName(ItemStack stack) {
        return PmpItem.colored(Component.translatable(this.getDescriptionId(stack)), color);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        PmpItem.tooltip(tip, latin, stages);
    }
}
